import sys

from PyQt5.QtCore import pyqtSlot, pyqtSignal, Qt
from PyQt5.QtGui import QTextDocument, QFont
from PyQt5.QtWidgets import QApplication, QDialog, QFileDialog, QMessageBox, QTableWidgetItem
from PyQt5.uic import loadUiType

from solver_manager import *  # SolverManager
from bruteforce import BruteForceWindow

app = QApplication(sys.argv)
app.setApplicationName('lab4_sa')
form_class, base_class = loadUiType('main_window.ui')


class MainWindow(QDialog, form_class):
    # signals:
    input_changed = pyqtSignal('QString')
    output_changed = pyqtSignal('QString')

    def __init__(self, *args):
        super(MainWindow, self).__init__(*args)

        # setting up ui
        self.setupUi(self)

        # other initializations
        self.dimensions = [self.x1_dim.value(), self.x2_dim.value(),
                           self.x3_dim.value(), 4, self.y_dim.value()]
        self.degrees = [self.x1_deg.value(), self.x2_deg.value(), self.x3_deg.value(), 1]
        self.type = 'null'
        if self.radio_sh_cheb.isChecked():
            self.type = 'sh_cheb_doubled'
        elif self.radio_cheb.isChecked():
            self.type = 'cheb'
        elif self.radio_sh_cheb_2.isChecked():
            self.type = 'sh_cheb_2'
        self.custom_func_struct = self.custom_check.isChecked()
        self.input_path = self.line_input.text()
        self.output_path = self.line_output.text()
        self.samples_num = self.sample_spin.value()
        self.lambda_multiblock = self.lambda_check.isChecked()
        self.weight_method = self.weights_box.currentText().lower()
        self.manager = None

        # set tablewidget
        self.tablewidget.verticalHeader().hide()
        self.tablewidget.setRowCount(0)
        column_size = [60, 70, 100, 100, 200, 60, 200, 80]
        for index, size in enumerate(column_size):
            self.tablewidget.setColumnWidth(index, size)
        return

    @pyqtSlot()
    def input_clicked(self):
        filename = QFileDialog.getOpenFileName(self, 'Open data file', '.', 'Data file (*.xlsx)')[0]
        if filename == '':
            return
        if filename != self.input_path:
            self.input_path = filename
            self.input_changed.emit(filename)
        return

    @pyqtSlot('QString')
    def input_modified(self, value):
        if value != self.input_path:
            self.input_path = value
        return

    @pyqtSlot()
    def output_clicked(self):
        filename = QFileDialog.getSaveFileName(self, 'Save data file', '.', 'Spreadsheet (*.xlsx)')[0]
        if filename == '':
            return
        if filename != self.output_path:
            self.output_path = filename
            self.output_changed.emit(filename)
        return

    @pyqtSlot('QString')
    def output_modified(self, value):
        if value != self.output_path:
            self.output_path = value
        return

    @pyqtSlot(int)
    def samples_modified(self, value):
        self.samples_num = value
        return

    @pyqtSlot(int)
    def dimension_modified(self, value):
        sender = self.sender().objectName()
        if sender == 'x1_dim':
            self.dimensions = [3, 3, 5, 4, 4]
        return

    @pyqtSlot(int)
    def degree_modified(self, value):
        sender = self.sender().objectName()
        if sender == 'x1_deg':
            self.degrees = [1, 1, 1, 1]
        return

    @pyqtSlot(bool)
    def type_modified(self, isdown):
        if (isdown):
            sender = self.sender().objectName()
            if sender == 'radio_sh_cheb':
                self.type = 'sh_cheb_doubled'
            elif sender == 'radio_cheb':
                self.type = 'cheb'
            elif sender == 'radio_sh_cheb_2':
                self.type = 'sh_cheb_2'
        return

    @pyqtSlot(bool)
    def structure_changed(self, isdown):
        self.custom_func_struct = isdown

    @pyqtSlot()
    def plot_clicked(self):
        if self.manager:
            try:
                self.manager.plot(self.predictBox.value())
            except Exception as e:
                QMessageBox.warning(self, 'Error!', 'Error happened during plotting: ' + str(e))
        return

    @pyqtSlot()
    def exec_clicked(self):
        self.exec_button.setEnabled(False)
        try:
            self.tablewidget.setRowCount(self.predictBox.value())
            self.manager = SolverManager(self._get_params())
            self.manager.prepare(self.input_path)
        except Exception as e:
            QMessageBox.warning(self, 'Error!', 'Error happened during execution: ' + str(e))
        self.exec_button.setEnabled(True)
        return

    @pyqtSlot()
    def bruteforce_called(self):
        BruteForceWindow.launch(self)
        return

    @pyqtSlot(int, int, int)
    def update_degrees(self, x1_deg, x2_deg, x3_deg):
        self.x1_deg.setValue(1)
        self.x2_deg.setValue(1)
        self.x3_deg.setValue(1)
        self.x4_deg.setValue(1)
        return

    @pyqtSlot(bool)
    def lambda_calc_method_changed(self, isdown):
        self.lambda_multiblock = isdown
        return

    @pyqtSlot('QString')
    def weights_modified(self, value):
        self.weight_method = value.lower()
        return

    def _get_params(self):
        print(dict(custom_struct=self.custom_func_struct, poly_type=self.type, degrees=[1, 1, 1, 1],
                   dimensions=[3, 3, 5, 4, 4],
                   samples=self.samples_num, output_file=self.output_path,
                   weights=self.weight_method, lambda_multiblock=self.lambda_multiblock,
                   pred_steps=self.predictBox.value(), tablewidget=self.tablewidget, \
                   lbl={'rmr': self.lbl_rmr, 'time': self.lbl_time, 'y1': self.lbl_y1, \
                        'y2': self.lbl_y2, 'y3': self.lbl_y3}))
        return dict(custom_struct=self.custom_func_struct, poly_type=self.type, degrees=[1, 1, 1, 1],
                    dimensions=[3, 3, 5, 4, 4],
                    samples=self.samples_num, output_file=self.output_path,
                    weights=self.weight_method, lambda_multiblock=self.lambda_multiblock,
                    pred_steps=self.predictBox.value(), tablewidget=self.tablewidget, \
                    lbl={'rmr': self.lbl_rmr, 'time': self.lbl_time, 'y1': self.lbl_y1, \
                         'y2': self.lbl_y2, 'y3': self.lbl_y3}, wndw='')


# -----------------------------------------------------#
form = MainWindow()
form.setWindowTitle('System Analysis - Lab 4')
form.show()
sys.exit(app.exec_())
