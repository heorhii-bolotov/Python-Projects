from sys import platform as sys_pf

if sys_pf == 'darwin':
    import matplotlib

    matplotlib.use("TkAgg")
from tkinter import font
from tkinter import *
from tkinter.ttk import Treeview, Style
from tkinter import filedialog, messagebox
from PyQt5.QtWidgets import QApplication
import os

from solver_manager import *
from bruteforce import BruteForceWindow



class Interface:
    def __init__(self, root):
        self.main_window = root
        self.screen_width = root.winfo_screenwidth()
        self.screen_height = root.winfo_screenheight()
        self.main_window.title('Лаба  №4')
        self.main_window.geometry("850x708+" + str(50) + "+" + str(int(self.screen_height / 2 - 708 / 2)))
        self.main_window.resizable(False, False)
        self.main_window.bind('<Escape>', self.Exit)
        self.background_main_window = 'orange'
        self.background_frames = 'lightblue'
        self.background_lables = 'steelblue'
        self.background_entries = 'lightgray'
        self.foreground = '#000000'
        self.main_window.configure(bg=self.background_main_window)
        self.CreateLeftFrame()
        self.CreateMiddleFrame()
        self.CreateRightFrame()
        self.CreteResultFrame()
        self.SetStartValues()
        # Style().configure('blue/gray.TButton', foreground=self.foreground, background=self.background_lables, activebackground=self.background_entries)
        myfont = font.Font(family='Helvetica', size=20, weight=font.BOLD)
        self.result_button = Button(self.main_window, text="Виконати", width=23, highlightbackground=self.background_lables,
                                    fg=self.foreground, font=font.Font(family='Times', size=10, weight=font.BOLD),
                                    activebackground=self.background_entries, relief='raised', borderwidth=1,
                                    cursor="hand2", command=self.Execute, highlightthickness=1)
        # self.result_button.place(x=592, y=200)
        self.result_button.place(x=42, y=570)


    def CreateLeftFrame(self):
        self.left_frame = Frame(self.main_window, width=275, height=320, bg=self.background_frames)
        # self.left_frame.place(x=25, y=10)
        # self.left_frame.place(x=550, y=10)
        self.left_frame.place(x=550, y=380)


        mylabelfont = font.Font(family='Helvetica', size=12)
        self.input_file_Label = Label(self.left_frame, text="Вхідний файл", width=24, font=mylabelfont,
                                      bg=self.background_lables, fg=self.foreground)
        self.input_file_Label.place(x=15, y=15)
        self.input_file_entry = Entry(self.left_frame, width=18, font=("Calibri", 11), bg=self.background_entries,
                                      fg=self.foreground, cursor="hand2")
        self.input_file_entry.place(x=15, y=50)
        img = PhotoImage('button.png')
        self.input_file_button = Button(self.left_frame, text="...", width=2, bg=self.background_lables,
                                        fg=self.foreground, font=("Calibri", 7),
                                        activebackground=self.background_entries, relief="flat", cursor="hand2",
                                        command=self.InputFile)
        self.input_file_button.place(x=212, y=50)

        self.output_file_Label = Label(self.left_frame, text="Результуючий файл", width=24, font=mylabelfont,
                                       bg=self.background_lables, fg=self.foreground)
        self.output_file_Label.place(x=15, y=90)
        self.output_file_entry = Entry(self.left_frame, width=18, font=("Calibri", 11), bg=self.background_entries,
                                       fg=self.foreground, cursor="hand2")
        self.output_file_entry.place(x=15, y=125)
        self.output_file_button = Button(self.left_frame, text="...", width=2, bg=self.background_lables,
                                         fg=self.foreground, font=("Calibri", 7),
                                         activebackground=self.background_entries, relief="flat", cursor="hand2",
                                         command=self.InputFile)
        self.output_file_button.place(x=212, y=125)

        self.vectors_label = Label(self.left_frame, text="Вектори", width=24, font=mylabelfont, bg="lavender",
                                   fg="midnightblue", borderwidth=1.5)
        self.vectors_label.place(x=15, y=175)

        self.vector_x1_label = Label(self.left_frame, text="x1", width=5, font=mylabelfont,
                                     bg=self.background_lables, fg=self.foreground)
        self.vector_x1_label.place(x=15, y=210)
        self.vector_x1_entry = Entry(self.left_frame, width=4, font=("Calibri", 11), bg=self.background_entries,
                                     fg=self.foreground, cursor="hand2")
        self.vector_x1_entry.place(x=77, y=210)

        self.vector_x2_label = Label(self.left_frame, text="x2", width=5, font=mylabelfont,
                                     bg=self.background_lables, fg=self.foreground)
        self.vector_x2_label.place(x=132, y=210)
        self.vector_x2_entry = Entry(self.left_frame, width=4, font=("Calibri", 11), bg=self.background_entries,
                                     fg=self.foreground, cursor="hand2")
        self.vector_x2_entry.place(x=193, y=210)

        self.vector_x3_label = Label(self.left_frame, text="x3", width=5, font=mylabelfont,
                                     bg=self.background_lables, fg=self.foreground)
        self.vector_x3_label.place(x=15, y=245)
        self.vector_x3_entry = Entry(self.left_frame, width=4, font=("Calibri", 11), bg=self.background_entries,
                                     fg=self.foreground, cursor="hand2")
        self.vector_x3_entry.place(x=77, y=245)

        self.vector_x4_label = Label(self.left_frame, text="x4", width=5, font=mylabelfont,
                                     bg=self.background_lables, fg=self.foreground)
        self.vector_x4_label.place(x=132, y=245)
        self.vector_x4_entry = Entry(self.left_frame, width=4, font=("Calibri", 11), bg=self.background_entries,
                                     fg=self.foreground, cursor="hand2")
        self.vector_x4_entry.place(x=193, y=245)

        self.vector_y_label = Label(self.left_frame, text="y", width=6, font=mylabelfont, bg=self.background_lables,
                                    fg=self.foreground)
        self.vector_y_label.place(x=15, y=280)
        self.vector_y_entry = Entry(self.left_frame, width=4, font=("Calibri", 11), bg=self.background_entries,
                                    fg=self.foreground, cursor="hand2")
        self.vector_y_entry.place(x=77, y=280)

    def InputFile(self):
        self.main_window.filename =  filedialog.askopenfilename(initialdir = os.path.realpath(__file__) , title = "Select file", filetypes = (("xlsx files","*.xlsx"),("all files","*.*")))
        self.input_file_entry.delete(0, 'end')
        self.input_file_entry.insert(0, self.main_window.filename)

    def OutputFile(self):
        self.main_window.filename = filedialog.askopenfilename(initialdir=os.path.realpath(__file__), title="Select file", filetypes=(("xlsx files", "*.xlsx"), ("all files", "*.*")))
        self.output_file_entry.delete(0, 'end')
        self.output_file_entry.insert(0, self.main_window.filename)

    def CreateMiddleFrame(self):
        self.middle_frame = Frame(self.main_window, width=275, height=320, bg=self.background_frames)
        # self.middle_frame.place(x=300, y=10)
        # self.middle_frame.place(x=275, y=10)
        self.middle_frame.place(x=275, y=380)

        mylabelfont = font.Font(family='Helvetica', size=12)
        self.structure_label = Label(self.middle_frame, text="Структура", width=24, font=mylabelfont,
                                     bg=self.background_lables, fg=self.foreground)
        self.structure_label.place(x=15, y=15)

        self.structure_values = [
            ("Стандартна", False),
            ("Власна", True),
        ]
        self.structure_value = BooleanVar()
        self.structure_value.set(True)
        self.structure_indents = 50

        for text, mode in self.structure_values:
            self.b = Radiobutton(self.middle_frame, text=text, variable=self.structure_value, value=mode,
                                 bg=self.background_frames, fg=self.foreground)
            self.b.pack(anchor=W)
            self.b.place(x=15, y=self.structure_indents)
            self.structure_indents += 25

        self.polynom_degree_label = Label(self.middle_frame, text="Степені поліномів", width=24, font=mylabelfont,
                                          bg=self.background_lables, fg=self.foreground)
        self.polynom_degree_label.place(x=15, y=110)

        self.for_x1_degree_label = Label(self.middle_frame, text="x1", width=5, font=mylabelfont,
                                         bg=self.background_lables, fg=self.foreground)
        self.for_x1_degree_label.place(x=15, y=145)
        self.for_x1_degree_entry = Entry(self.middle_frame, width=4, font=mylabelfont, bg=self.background_entries,
                                         fg=self.foreground, cursor="hand2")
        self.for_x1_degree_entry.place(x=77, y=145)

        self.for_x2_degree_label = Label(self.middle_frame, text="x2", width=5, font=mylabelfont,
                                         bg=self.background_lables, fg=self.foreground)
        self.for_x2_degree_label.place(x=132, y=145)
        self.for_x2_degree_entry = Entry(self.middle_frame, width=4, font=("Calibri", 11), bg=self.background_entries,
                                         fg=self.foreground, cursor="hand2")
        self.for_x2_degree_entry.place(x=193, y=145)

        self.for_x3_degree_label = Label(self.middle_frame, text="x3", width=5, font=mylabelfont,
                                         bg=self.background_lables, fg=self.foreground)
        self.for_x3_degree_label.place(x=15, y=180)
        self.for_x3_degree_entry = Entry(self.middle_frame, width=4, font=("Calibri", 11), bg=self.background_entries,
                                         fg=self.foreground, cursor="hand2")
        self.for_x3_degree_entry.place(x=77, y=180)

        self.for_x4_degree_label = Label(self.middle_frame, text="x4", width=5, font=mylabelfont,
                                         bg=self.background_lables, fg=self.foreground)
        self.for_x4_degree_label.place(x=132, y=180)
        self.for_x4_degree_entry = Entry(self.middle_frame, width=4, font=("Calibri", 11), bg=self.background_entries,
                                         fg=self.foreground, cursor="hand2")
        self.for_x4_degree_entry.place(x=193, y=180)

        self.prediction_label = Label(self.middle_frame, text="Передбачення", width=24, font=mylabelfont,
                                      bg=self.background_lables, fg=self.foreground)
        self.prediction_label.place(x=15, y=220)

        self.prediction_step_label = Label(self.middle_frame, text="Крок", width=10, font=mylabelfont,
                                           bg=self.background_lables, fg=self.foreground)
        self.prediction_step_label.place(x=15, y=255)
        self.prediction_step_entry = Entry(self.middle_frame, width=9, font=("Calibri", 11), bg=self.background_entries,
                                           fg=self.foreground, cursor="hand2")
        self.prediction_step_entry.place(x=143, y=255)

        self.prediction_set_label = Label(self.middle_frame, text="Сет", width=10, font=mylabelfont,
                                          bg=self.background_lables, fg=self.foreground)
        self.prediction_set_label.place(x=15, y=285)
        self.prediction_set_entry = Entry(self.middle_frame, width=9, font=("Calibri", 11), bg=self.background_entries,
                                          fg=self.foreground, cursor="hand2")
        self.prediction_set_entry.place(x=143, y=285)

    def CreateRightFrame(self):
        self.right_frame = Frame(self.main_window, width=250, height=165, bg=self.background_frames)
        # self.right_frame.place(x=575, y=10)
        # self.right_frame.place(x=25, y=10)
        self.right_frame.place(x=25, y=380)
        mylabelfont = font.Font(family='Helvetica', size=12)
        self.additionally_label = Label(self.right_frame, text="Ваги цільових функцій", width=24, font=mylabelfont,
                                        bg="lavender", fg="midnightblue", borderwidth=1.5)
        self.additionally_label.place(x=15, y=15)

        self.additionally_values = [
            ("Середнє арифметичне", "average"),
            ("Через максимум і мінімум", "scaled"),
        ]

        self.additionally_value = StringVar()
        self.additionally_value.set("scaled")
        self.additionally_indents = 50

        myfont = font.Font(family='Helvetica', size=12, weight=font.BOLD)
        self.box = Listbox(self.right_frame, bg=self.background_frames, fg=self.foreground, height=20, width=20, borderwidth=0, font=myfont)
        for text, _ in self.additionally_values:
            self.box.insert(END, text)
            self.box.pack(anchor=W)
            self.box.place(x=20, y=self.additionally_indents)
            self.additionally_indents += 8
        self.box.place(x=15, y=50)

        # for text, mode in self.additionally_values:
        #     self.a = Radiobutton(self.right_frame, text=text, variable=self.additionally_value, value=mode,
        #                          bg=self.background_frames, fg=self.foreground)
        #     self.a.pack(anchor=W)
        #     self.a.place(x=15, y=self.additionally_indents)
        #     self.additionally_indents += 25

        self.lambda_flag_value = BooleanVar()
        self.lambda_button = Checkbutton(self.right_frame, text="Визначати Lambda з трьох\n систем рівнянь",
                                         variable=self.lambda_flag_value, onvalue=True, offvalue=False,
                                         bg=self.background_frames, fg=self.foreground)
        self.lambda_button.place(x=15, y=105)

    def CreteResultFrame(self):
        self.result_frame = Frame(self.main_window, width=800, height=360, bg=self.background_main_window)
        # self.result_frame.place(x=26, y=340)
        self.result_frame.place(x=26, y=10)
        mylabelfont = font.Font(family='Helvetica', size=20, weight=font.BOLD)
        self.result_label = Label(self.result_frame, text="Результат", width=110, font=mylabelfont,
                                  bg=self.background_lables, fg=self.foreground)

        self.result_label.place(x=-230, y=5)

        self.tree_frame = Frame(self.result_frame)
        self.tree_frame.place(x=0, y=40)

        self.columns = [("Час", 50), ("Рівень води у \nвхідному резервуарі", 120), ("Напір", 70), ("Температура", 100),
                        ('Рівень води у \nвихідному резервуарі', 120), ("Стан функціонування", 70),
                        ("Ризик \nаварії", 110),
                        ("Причина нештатної ситуації", 70), ("Рівень небезпеки", 70)]
        self.style = Style()
        self.style.configure("mystyle.Treeview.Heading", font=('Canvas', 9, 'bold'), highlightbackground='lightblue', foreground='midnightblue')
        self.tree = Treeview(self.tree_frame, selectmode="extended", style="mystyle.Treeview", columns=self.columns,
                             show="headings", height=14)

        self.scrollbar_vertical = Scrollbar(self.tree_frame, orient=VERTICAL, command=self.tree.yview)
        self.scrollbar_vertical.pack(side=RIGHT, fill=Y)
        self.tree.configure(yscrollcommand=self.scrollbar_vertical.set)

        for i in range(len(self.columns)):
            self.tree.heading(i, text=self.columns[i][0], anchor=CENTER, )
            self.tree.column(i, width=self.columns[i][1], anchor=CENTER, minwidth=60)

        self.tree.pack(side=LEFT, fill=BOTH, expand=False)

    def SetStartValues(self):
        self.vector_x1_entry.insert(0, 3)
        self.vector_x2_entry.insert(0, 3)
        self.vector_x3_entry.insert(0, 5)
        self.vector_x4_entry.insert(0, 4)
        self.vector_y_entry.insert(0, 4)
        self.for_x1_degree_entry.insert(0, 1)
        self.for_x2_degree_entry.insert(0, 1)
        self.for_x3_degree_entry.insert(0, 1)
        self.for_x4_degree_entry.insert(0, 1)
        self.prediction_step_entry.insert(0, 10)
        self.prediction_set_entry.insert(0, 50)
        self.input_file_entry.insert(0, '/Users/macair/Downloads/clean_project/norm_final.xlsx')
        self.output_file_entry.insert(0, '/Users/macair/Downloads/clean_project/result.xlsx')

    def PackData(self):
        self.degrees = list(map(int, [self.for_x1_degree_entry.get(), self.for_x2_degree_entry.get(),
                                      self.for_x3_degree_entry.get(), self.for_x4_degree_entry.get()]))
        self.dimensions = list(map(int,
                                   [self.vector_x1_entry.get(), self.vector_x2_entry.get(), self.vector_x3_entry.get(),
                                    self.vector_x4_entry.get(), self.vector_y_entry.get()]))
        ind = 0
        if self.box.curselection():
            ind = self.box.curselection()[0]

        return dict(custom_struct=self.structure_value.get(), poly_type='sh_cheb_doubled',
                    degrees=self.degrees, dimensions=self.dimensions,
                    samples=int(self.prediction_set_entry.get()), output_file=self.output_file_entry.get(),
                    weights=self.additionally_values[ind][1], lambda_multiblock=self.lambda_flag_value.get(),
                    pred_steps=int(self.prediction_step_entry.get()), tablewidget=self.tree, wndw=self.main_window)

    def Execute(self):
        try:
            self.manager = SolverManager(self.PackData())
            self.manager.prepare(self.input_file_entry.get())
        except Exception as e:
            messagebox.showinfo("Error", str(e))

    def Exit(self, event):
        self.main_window.destroy()


root = Tk()
app = QApplication(sys.argv)
q = Interface(root)
root.mainloop()
