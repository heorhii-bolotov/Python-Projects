from django.apps import AppConfig


class RoutingConfig(AppConfig):
    name = 'routing'
