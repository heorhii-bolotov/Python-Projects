from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET, require_POST
from django.http import HttpResponse
from django.core.exceptions import SuspiciousOperation
from functools import wraps
import requests
import base64

# Create your views here.


@require_GET
def simple_route(request):
    return HttpResponse()


def slug_route(request, arg):
    return HttpResponse(arg)


def sum_route(request, arg1, arg2):
    try:
        resp = int(arg1) + int(arg2)
        return HttpResponse(resp)
    except (ValueError, TypeError):
        raise SuspiciousOperation


def require_int_args(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        q = func(*args, **kwargs)
        if not q:
            raise SuspiciousOperation
        else:
            try:
                content = sum([sum(map(int, q.getlist(key))) for key in q])
                return HttpResponse(content)
            except (ValueError, TypeError):
                raise SuspiciousOperation

    return wrapper


@require_GET
@require_int_args
def sum_get_method(request):
    return request.GET


@require_POST
@require_int_args
def sum_post_method(request):
    return request.POST

