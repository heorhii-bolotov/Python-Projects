from django.apps import AppConfig


class TemplateConfig(AppConfig):
    name = 'template'
