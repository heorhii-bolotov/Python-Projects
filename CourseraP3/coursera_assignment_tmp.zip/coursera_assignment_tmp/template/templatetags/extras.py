from django import template

register = template.Library()


@register.filter(name='inc')
def inc(value, incr):
    """ Increments 'incr' to value """
    try:
        value, incr = int(value), int(incr)
        return value + incr
    except ValueError:
        return ''


@register.simple_tag(name='division')
def division(dividend, divider, to_int=False):
    try:
        dividend, divider = int(dividend), int(divider)
        value = dividend / divider
        return int(value) if to_int else value
    except ValueError:
        return ''
