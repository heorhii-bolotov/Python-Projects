from django.shortcuts import render
from django.views.decorators.http import require_http_methods

# Create your views here.


@require_http_methods(['POST', 'GET'])
def echo(request):
    method = request.method
    q = request.POST if method == 'POST' else request.GET
    params = '\n'.join([f'{k}: {v}' for k in q for v in q.getlist(k)])

    context = {
        'method': method,
        'params': params,
        'header': request.META.get('HTTP_X_PRINT_STATEMENT'),
    }

    return render(request, 'echo.html', context)


def filters(request):
    return render(request, 'filters.html', context={
        'a': request.GET.get('a', 1),
        'b': request.GET.get('b', 1)
    })


def extend(request):
    return render(request, 'extend.html', context={
        'a': request.GET.get('a'),
        'b': request.GET.get('b')
    })

